# CT-472 — AI Model Testing Evidence

**Source:** `IQRA_YOUR_WORK (1).ipynb` (saved notebook outputs).  
**Purpose:** Standalone testing-results section for academic report and supervisor demonstration.  
**Scope:** These are recorded notebook outputs, not a fresh independent rerun.

## 1. Sales forecasting — chronological holdout test (Cells 15–17)

**Method:** The 36 historical monthly sales observations were ordered chronologically. The first **33 months (November 2023–July 2026)** were used for training; the last **3 months (August–October 2026)** were reserved for testing. The notebook reports `PASS` for the no-future-data-leakage split.

| Model | Test MAE | Test RMSE |
|---|---:|---:|
| Seasonal Naive baseline | 26,496,721.06 | 35,514,854.56 |
| Ridge Regression | **21,429,954.87** | **25,485,789.75** |

Ridge reduced holdout MAE by **19.12%** and RMSE by **28.24%** compared with the baseline (calculated from the displayed results).

**Monthly absolute errors:**

| Test month | Baseline absolute error | Ridge absolute error |
|---|---:|---:|
| August 2026 | 9,763,264.17 | approximately 2,556,013 |
| September 2026 | 9,786,835.58 | approximately 26,594,400 |
| October 2026 | 59,940,063.44 | approximately 35,139,460 |

*Note:* Ridge per-month absolute errors were displayed in scientific notation; approximations above reflect the notebook display, whereas aggregate MAE/RMSE are the notebook's printed precision.

**Interpretation:** Ridge performed better than the seasonal baseline on the final three-month holdout by both aggregate metrics. This is a small holdout, so rolling validation provides additional evidence.

## 2. Sales forecasting — rolling-origin validation (Cell 18)

Four chronological three-month test windows were evaluated:

| Training end | Test period | Baseline MAE (approx.) | Ridge MAE (approx.) |
|---|---|---:|---:|
| July 2025 | Aug–Oct 2025 | 45.07M | 22.21M |
| October 2025 | Nov 2025–Jan 2026 | 75.14M | 66.83M |
| January 2026 | Feb–Apr 2026 | 29.26M | 49.35M |
| April 2026 | May–Jul 2026 | 62.06M | 60.28M |

| Model | Mean MAE across folds | Mean RMSE across folds |
|---|---:|---:|
| Seasonal Naive | 52.88241M | 59.06585M |
| Ridge Regression | **49.66780M** | **57.60943M** |

**Interpretation:** Ridge had better average MAE and RMSE across folds, but it did **not** win every window: the seasonal baseline had lower error in February–April 2026. The notebook reports `ROLLING VALIDATION COMPLETED`.

## 3. Z-Score anomaly screening (Cell 23)

- Observations: **36 monthly sales values**.
- Historical mean monthly sales: **2,495,827,059.01**.
- Standard deviation: **68,014,818.14**.
- Absolute Z-Score threshold: **2.0**.
- Raw monthly-sales anomalies flagged: **2**.

| Month | Z-Score | Classification |
|---|---:|---|
| February 2025 | −3.339524 | Unusually Low Sales |
| February 2026 | −2.602206 | Unusually Low Sales |

## 4. Calendar-day normalization check (Cell 24)

The model was checked again using **sales per calendar day** to account for shorter months.

| Check | Flagged months |
|---|---:|
| Original monthly Z-Score | 2 |
| Daily-sales Z-Score | **0** |

**Interpretation:** Neither February month remained flagged after calendar-day adjustment. This suggests the raw monthly flags were affected by month length; they should not be presented as confirmed business anomalies.

## 5. Isolation Forest screening on real historical months (Cells 25 and 27)

- Historical observations: **36 months**.
- Isolation Forest flagged **2 months**: **November 2023** and **January 2025**.
- Daily-normalized Z-Score flagged **0 months**.
- Final review labels: **34 No Flag**, **2 Secondary Review**, **0 Priority Review**.

| Month | Isolation anomaly score | Final review status |
|---|---:|---|
| November 2023 | 0.679112 | Secondary Review |
| January 2025 | 0.672325 | Secondary Review |

**Interpretation:** These are model-generated review candidates, not verified fraud, errors, or proven abnormal business events.

## 6. Controlled anomaly injection test (Cell 26)

Three sales months were deliberately modified in a **test copy of the data** to check whether the detection methods could identify known injected changes.

| Injected month | Original sales (approx.) | Modified sales (approx.) | Daily Z-Score detected? | Isolation Forest detected? |
|---|---:|---:|---|---|
| June 2024 | 2.543B | 1.526B | Yes | Yes |
| September 2025 | 2.474B | 3.711B | Yes | Yes |
| March 2026 | 2.552B | 1.659B | Yes | Yes |

| Method | Precision | Recall | F1 score | Total months flagged |
|---|---:|---:|---:|---:|
| Daily Z-Score | **1.00** | **1.00** | **1.00** | 3 |
| Isolation Forest | 0.60 | **1.00** | 0.75 | 5 |

**Interpretation:** Both methods detected all three injected anomalies (recall 100%). Isolation Forest additionally flagged two non-injected months (November 2023 and January 2025), so its precision was 60% under the test's injected-label definition. The Z-Score method flagged only the three injected months. **These are controlled synthetic-test metrics, not accuracy guarantees on real labeled anomalies.**

## 7. Forecast outputs — produced after testing (Cells 19 and 39)

After evaluation, the final Ridge model was trained on all **36 historical months** and produced these three future forecasts, later verified in Neon:

| Forecast month | Predicted sales |
|---|---:|
| November 2026 | 2,508,635,373.60 |
| December 2026 | 2,510,714,554.68 |
| January 2027 | 2,490,819,159.82 |

These are **future predictions**, not test-set ground-truth results or measured forecasting accuracy.

## 8. Database and saved-model verification (Cells 38–39 and 45)

**Neon database validation:**

| Check | Notebook result |
|---|---|
| Registered AI models | 3 |
| Stored forecast records | 3 |
| Stored anomaly records | 36 |
| Forecast values reconciled | PASS |
| Anomaly amounts and flags reconciled | PASS |
| Duplicate checks for model/month | PASS |

**Saved model verification:**

| Check | Notebook result |
|---|---|
| Reloaded Ridge coefficients | MATCH |
| Reloaded Ridge intercept | MATCH |
| Reloaded Isolation Forest predictions | MATCH |
| Reloaded Isolation Forest anomaly scores | MATCH |
| Saved vs original historical month count | 36 vs 36 |
| Overall model artifact verification | PASSED |

The saved-model verification output also contained scikit-learn warnings about missing feature names in the input array. The notebook nevertheless reported matching predictions and scores; the warning should be noted rather than hidden.

## 9. Suggested report conclusion

The CT-472 AI component was evaluated using a chronological holdout test and rolling-origin validation for monthly sales forecasting, plus statistical screening, calendar normalization, and controlled anomaly injection for anomaly detection. Ridge Regression achieved a lower holdout MAE (21.43 million) than the seasonal naive baseline (26.50 million), and slightly better average errors across four rolling validation folds. In controlled anomaly tests, daily Z-Score detected all three injected anomalies with no additional flagged months, while Isolation Forest detected all three but also flagged two non-injected months. AI result reconciliation in Neon and saved-model reload checks passed. These results demonstrate recorded model evaluation and integration checks; they do not replace future production end-to-end testing or establish accuracy on independently labeled real-world anomalies.

---
**Evidence index:** Forecast split Cell 15; baseline Cell 16; Ridge Cell 17; rolling validation Cell 18; future forecasts Cell 19; Z-Score Cell 23; calendar adjustment Cell 24; Isolation Forest Cell 25; injected anomaly testing Cell 26; final anomaly screening Cell 27; database loading/validation Cells 38–39; saved model verification Cell 45. Cell numbers refer to the notebook's zero-based cell index, not necessarily its printed Colab cell labels.
