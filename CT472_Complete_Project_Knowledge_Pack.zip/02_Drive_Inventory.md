# Google Drive reference (historical audit; not a live Drive listing)
Root `/content/drive/MyDrive/Enterprise_DW_Project`. The full Drive is not included. The original audit recorded 207 files across 11 folders before new testing artifacts were added. The following is the documented layout, not a guarantee that every current file is present.

| Folder | Recorded files | Purpose |
|---|---:|---|
| raw_snapshots/20261105_200624 | 106 | 99 Parquet files + 7 CSV manifests/reports across four source folders |
| Sales_ETL_Package | 16 | prepared sales dimensions/facts, mapping and checks |
| Purchasing_ETL_Package | 15 | prepared purchase dimensions/fact, mapping and checks |
| Inventory_ETL_Package | 9 | warehouse/movement dimensions, three inventory facts and checks |
| Finance_ETL_Package | 14 | four finance/shared dimensions, two facts, mappings and validations |
| finance_mapping | 3 | finance source-to-target documentation |
| ERD_Deliverables | 8 | ERD and architecture deliverables |
| Phase_1_Dimensional_Design | 22 | dimensional design, schemas and physical preparation artifacts |
| AI_Forecasting | 5 | historical monthly sales, model comparison, rolling validation, three-month predictions, forecast chart |
| AI_Anomaly_Detection | 5 | experiment summary, model evaluation, flagged months, monthly results, injection test |
| AI_Models | 4 | timestamped directory with serialized models and manifest |

AI_Models/20261111_175459_479473_UTC: Historical_Monthly_Sales.csv, Ridge_Forecasting_Model.joblib, Isolation_Forest_Model.joblib, Model_Manifest.json.
AI_Forecasting: Historical_Monthly_Sales.csv, Model_Comparison.csv, Rolling_Validation.csv, Sales_Forecast_3_Months.csv, Sales_Forecast_Chart.png.
AI_Anomaly_Detection: Anomaly_Experiment_Summary.txt, Anomaly_Model_Evaluation.csv, Flagged_Sales_Months.csv, Monthly_Anomaly_Results.csv, Synthetic_Anomaly_Test_Results.csv.

## Later testing folder: Final_End_to_End_Testing
- 01_Baseline/20261115_111720_088739_UTC: Source_Baseline.csv, Warehouse_Baseline.csv, Baseline_Summary.csv, Baseline_Manifest.json.
- 02_Integrity_Audit: Integrity_Audit_<timestamp>.csv.
- 03_Backup/20261115_112054_663946_UTC: Relational_Schema_Backup.json, MongoDB_Schema_Backup.json, Date_Validation.json and baseline evidence.
- 04_Data_Backup/20261115_112526_130138_UTC: compressed SQL rows and Mongo BSON exports; Backup_Manifest.csv with checksums. Large backup deliberately omitted.
- 05_Incremental_Batches/E2E_TEST_20261115_001: Prepared_Test_Batch.pkl, Incremental_Parquet, Extraction_Manifest.csv, transformation/load evidence.
- 06_Automated_Pipeline: ETL_Checkpoints.json, Batches/AUTO_* with manifest and Parquet; Pending_Batch.json present only during pending processing. Never reset checkpoints just to rerun.
- 07_AI_Automation: timestamped verification CSVs/reports, Latest_AI_Run.json, Versions directory for future candidate artifacts.
- 08_PowerBI_Integration: Expected_Dashboard_KPIs.csv, Latest_AI_Forecasts.csv, Latest_AI_Anomalies.csv, Integration_Validation.json.
- 09_Final_Production_Validation/20261115_125802_059440: First_Pipeline_Run.json, Second_Pipeline_Run.json, Final_Validation_Results.csv, Final_Database_Counts.csv, Final_Dashboard_KPIs.csv, Final_AI_Forecasts.csv, Final_AI_Anomalies.csv, Final_Project_Summary.json, Operational_Handover.txt.

Original 12 analytics CSVs exported to Colab /content/PowerBI_12_Analytics_CSV then zipped; copied into this pack from the provided archive. They are historical, not final updated data. No need to upload millions of transactional records to report author. Use manifests and saved outputs as evidence.
